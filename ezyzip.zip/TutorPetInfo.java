

public class TutorPetInfo {
    private String nomeTutor;
    private String cpfTutor;
    private String telefoneTutor;
    private String nomePet;
    private String racaPet;
    private String especiePet;
    private String pesoPet;
  
    public TutorPetInfo(String nomeTutor, String cpfTutor, String telefoneTutor,
                        String nomePet, String racaPet, String especiePet, String pesoPet) {
        this.nomeTutor = nomeTutor;
        this.cpfTutor = cpfTutor;
        this.telefoneTutor = telefoneTutor;
        this.nomePet = nomePet;
        this.racaPet = racaPet;
        this.especiePet = especiePet;
        this.pesoPet = pesoPet;
    }
    
    public TutorPetInfo(String nomeTutor, String telefoneTutor,
    String nomePet, String racaPet, String especiePet, String pesoPet){
        this.nomeTutor = nomeTutor;
        this.telefoneTutor = telefoneTutor;
        this.nomePet = nomePet;
        this.racaPet = racaPet;
        this.especiePet = especiePet;
        this.pesoPet = pesoPet;
    }
    public TutorPetInfo( String cpfTutor){
                this.cpfTutor = cpfTutor;

    }
    

    public String getNomeTutor() {
        return nomeTutor;
    }

    public void setNomeTutor(String nomeTutor) {
        this.nomeTutor = nomeTutor;
    }

    public String getCpfTutor() {
        return cpfTutor;
    }

    public void setCpfTutor(String cpfTutor) {
        this.cpfTutor = cpfTutor;
    }

    public String getTelefoneTutor() {
        return telefoneTutor;
    }

    public void setTelefoneTutor(String telefoneTutor) {
        this.telefoneTutor = telefoneTutor;
    }

    public String getNomePet() {
        return nomePet;
    }

    public void setNomePet(String nomePet) {
        this.nomePet = nomePet;
    }

    public String getRacaPet() {
        return racaPet;
    }

    public void setRacaPet(String racaPet) {
        this.racaPet = racaPet;
    }

    public String getEspeciePet() {
        return especiePet;
    }

    public void setEspeciePet(String especiePet) {
        this.especiePet = especiePet;
    }

    public String getPesoPet() {
        return pesoPet;
    }

    public void setPesoPet(String pesoPet) {
        this.pesoPet = pesoPet;
    }


}

