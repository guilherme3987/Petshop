import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ExcluirDados extends JFrame{
  JTextField buscar_cpf = new JTextField(10);
  CadastrarTP cadastrarTP;
  ArrayList<TutorPetInfo> tutorPetLista;
  JButton excluir;

  public ExcluirDados(CadastrarTP cadastrarTP){
     this.cadastrarTP = cadastrarTP;
    this.tutorPetLista = cadastrarTP.getTutorPetLista();
    this.setTitle("Excluir dados");
    this.setSize(400, 400);
    this.setResizable(false);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    excluir = new JButton("Excluir");
    JPanel panel = new JPanel(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();

    panel.add(new Label("Digíte cpf (somente números)"));


    
    excluir.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (buscar_cpf.getText().trim().isEmpty() || buscar_cpf.getText().length() != 11 || !buscar_cpf.getText().matches("\\d+")) {
                JOptionPane.showMessageDialog(panel, "CPF inválido");
                return;
            } else {
                boolean encontrado = false;
                int i = 0;
    
                while (i < tutorPetLista.size()) {
                    TutorPetInfo tutor = tutorPetLista.get(i);
                    if (tutor.getCpfTutor().equals(buscar_cpf.getText().trim())) {
                        tutorPetLista.remove(i); 
                        encontrado = true;
                    } else {
                        i++;
                    }
                }
    
                if (encontrado) {
                    JOptionPane.showMessageDialog(panel, "CPF encontrado e dados do tutor e pet removidos");
                } else {
                    JOptionPane.showMessageDialog(panel, "CPF não encontrado");
                }
            }
        }
    });
    

    gbc.gridx = 0;
    gbc.gridy = -5;
    panel.add(buscar_cpf,gbc);

    gbc.gridx = 0;
    gbc.gridy = 7;
    gbc.gridwidth = 2;
    panel.add(excluir,gbc );

    this.add(panel);
    this.setVisible(true);
  }
}