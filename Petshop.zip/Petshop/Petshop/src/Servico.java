public abstract class Servico {
    protected String nomeServico;
    protected float preco;
    //protected Pet pet;

    
}