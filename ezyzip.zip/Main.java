import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame {
    public static void main(String[] args) {
      CadastrarTP janelaCadastro = new CadastrarTP();
      
        System.out.println("...");

        JFrame janelaPrincipal = new JFrame("PetShop");
        janelaPrincipal.setSize(500, 500);
        janelaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel painel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JButton cadastrar = new JButton("Cadastrar");
        JButton consultar = new JButton("Consultar");
        JButton excluirDados = new JButton("Excluir Dados");
        JButton contratarServico = new JButton("Contratar Serviço");
        JButton alterarDados = new JButton("Alterar Dados");
        JButton imprimirDados = new JButton("Imprimir Dados");

        cadastrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //CadastrarTP janelaCadastro = new CadastrarTP();
                janelaCadastro.setVisible(true);
            }
        });

        contratarServico.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ContratarServico janelaServico = new ContratarServico(janelaCadastro);
                janelaServico.setVisible(true);
            }
        });

        consultar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              Consultar janelaConsulta = new Consultar(janelaCadastro);
                janelaConsulta.setVisible(true);
            }
        });

        excluirDados.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ExcluirDados janelaExcluir = new ExcluirDados(janelaCadastro);
                janelaExcluir.setVisible(true);
            }
        });

        alterarDados.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AlterarDados janelaAlterar = new AlterarDados(janelaCadastro,CadastrarTP.getTutorPetLista());
                janelaAlterar.setVisible(true);
            }
        });

        imprimirDados.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ImprimirDados janelaImprimir = new ImprimirDados(janelaCadastro);
                janelaImprimir.setVisible(true);
            }
        });

        Dimension buttonSize = new Dimension(150, 50);
        cadastrar.setPreferredSize(buttonSize);
        consultar.setPreferredSize(buttonSize);
        excluirDados.setPreferredSize(buttonSize);
        contratarServico.setPreferredSize(buttonSize);
        alterarDados.setPreferredSize(buttonSize);
        imprimirDados.setPreferredSize(buttonSize);

        cadastrar.setHorizontalAlignment(SwingConstants.CENTER);
        consultar.setHorizontalAlignment(SwingConstants.CENTER);
        excluirDados.setHorizontalAlignment(SwingConstants.CENTER);
        contratarServico.setHorizontalAlignment(SwingConstants.CENTER);
        alterarDados.setHorizontalAlignment(SwingConstants.CENTER);
        imprimirDados.setHorizontalAlignment(SwingConstants.CENTER);

        gbc.gridx = 0;
        gbc.gridy = 0;
        painel.add(cadastrar, gbc);

        gbc.gridx = 1;
        painel.add(consultar, gbc);

        gbc.gridx = 2;
        painel.add(excluirDados, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        painel.add(contratarServico, gbc);

        gbc.gridx = 1;
        painel.add(alterarDados, gbc);

        gbc.gridx = 2;
        painel.add(imprimirDados, gbc);

        janelaPrincipal.add(painel);
        janelaPrincipal.setVisible(true);
    }
}


/*
· Incluir novo “produto”

· Consultar um “produto”

· Alterar dados de um “produto”

· Excluir dados de um “produto”

· Imprimir em tela lista de “produtos”.
 */