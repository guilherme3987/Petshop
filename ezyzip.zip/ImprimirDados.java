import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ImprimirDados extends JFrame {

  JButton imprimirDadosTutor = new JButton("Imprimir dados  tutores");
  JButton imprimirDadosPet = new JButton("Imprimir dados pets");
  CadastrarTP cadastrarTP;
  ArrayList<TutorPetInfo> tutorPetLista;

  public ImprimirDados(CadastrarTP cadastrarTP) {
    this.cadastrarTP = cadastrarTP;
    this.tutorPetLista = cadastrarTP.getTutorPetLista();

    this.setTitle("Imprimir dados");
    this.setSize(400, 400);
    this.setResizable(false);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    JPanel panel = new JPanel(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);

    imprimirDadosTutor.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        for (TutorPetInfo tutor : tutorPetLista) {
            JOptionPane.showMessageDialog(panel, 
            "\nCadastro para pet: "+tutor.getNomePet()+"\n"+
            "Nome do Tutor: " + tutor.getNomeTutor()+
            "\nCPF do Tutor: " + tutor.getCpfTutor()+ 
            "\nTelefone do Tutor: " + tutor.getTelefoneTutor());
        }
      }
    });
    imprimirDadosPet.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        for (TutorPetInfo pets : tutorPetLista) {
            JOptionPane.showMessageDialog(panel,
            "\nCadastro para tutor:"+pets.getNomeTutor()+"\n"+
            "\nNome do Pet: " + pets.getNomePet() + 
            "\nRaça do Pet: " + pets.getRacaPet() + 
            "\nEspécie do Pet: " + pets.getEspeciePet() + 
            "\nPeso do Pet: " + pets.getPesoPet());
        }
      }
    });
    gbc.gridx = 0;
    gbc.gridy = 7;
    gbc.gridwidth = 2;
    panel.add(imprimirDadosTutor, gbc);

    gbc.gridx = 0;
    gbc.gridy = 10;
    gbc.gridwidth = 5;
    panel.add(imprimirDadosPet, gbc);

    this.add(panel);
    this.setVisible(true);
  }
}

