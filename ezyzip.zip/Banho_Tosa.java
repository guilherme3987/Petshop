public class Banho_Tosa extends Servico{
    double taxa_banhoEtosa;

    public Banho_Tosa(String nomeServico, double taxa_banhoEtosa) {
        super(nomeServico);
        this.taxa_banhoEtosa = taxa_banhoEtosa;
        //TODO Auto-generated constructor stub
    }

    public double getTaxa_banhoEtosa() {
        return taxa_banhoEtosa;
    }

    public void setTaxa_banhoEtosa(double taxa_banhoEtosa) {
        this.taxa_banhoEtosa = taxa_banhoEtosa;
    }
    
}
