import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class AlterarDados extends JFrame {
    private JTextField cpfTutorBuscar = new JTextField(10);
    private JTextField novoTelefone = new JTextField(10); 
    private JTextField novoNomePet = new JTextField(10);
    private JTextField novaRacaPet = new JTextField(10);
    private JTextField novaEspeciePet = new JTextField(10);
    private JTextField novoPesoPet = new JTextField(10);
    private JButton buscar = new JButton("Buscar");
    private JButton alterar = new JButton("Alterar");

    private ArrayList<TutorPetInfo> tutorPetLista;

    public AlterarDados(CadastrarTP cadastrarTP, ArrayList<TutorPetInfo> tutorPetLista) {
        this.tutorPetLista = tutorPetLista;
        setTitle("Alterar ");
        setResizable(false);
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("CPF do Tutor para Buscar:"), gbc);
        gbc.gridx = 1;
        panel.add(cpfTutorBuscar, gbc);
        gbc.gridx = 2;
        panel.add(buscar, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Novo Telefone:"), gbc);
        gbc.gridx = 1;
        panel.add(novoTelefone, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Novo Nome do Pet:"), gbc);
        gbc.gridx = 1;
        panel.add(novoNomePet, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Nova Raça do Pet:"), gbc);
        gbc.gridx = 1;
        panel.add(novaRacaPet, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Nova Espécie do Pet:"), gbc);
        gbc.gridx = 1;
        panel.add(novaEspeciePet, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(new JLabel("Novo Peso do Pet:"), gbc);
        gbc.gridx = 1;
        panel.add(novoPesoPet, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2; 
        panel.add(alterar, gbc);

        buscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cpfToSearch = cpfTutorBuscar.getText();
                TutorPetInfo tutorToDisplay = null;

                for (TutorPetInfo tutorPetInfo : tutorPetLista) {
                    if (tutorPetInfo.getCpfTutor().equals(cpfToSearch)) {
                        tutorToDisplay = tutorPetInfo;
                        break;
                    }
                }

                if (tutorToDisplay != null) {
                    novoTelefone.setText(tutorToDisplay.getTelefoneTutor());
                    novoNomePet.setText(tutorToDisplay.getNomePet());
                    novaRacaPet.setText(tutorToDisplay.getRacaPet());
                    novaEspeciePet.setText(tutorToDisplay.getEspeciePet());
                    novoPesoPet.setText(tutorToDisplay.getPesoPet());
                } else {
                    JOptionPane.showMessageDialog(panel, "Tutor não encontrado com o CPF fornecido");
                }
            }
        });

        alterar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
 
            }
        });

        add(panel);
        setVisible(true);
    }
}
