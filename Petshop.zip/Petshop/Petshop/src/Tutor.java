import java.util.ArrayList;

public class Tutor {
    private String nome;
    private String cpf;
    private ArrayList<Pet> listaDePets;
    private ArrayList<Tutor> listaDeTutores;

    // Construtor
    public Tutor(String nome, String cpf) {
        this.nome = nome;
        this.cpf = cpf;
        this.listaDePets = new ArrayList<>();
    }

    public ArrayList<Tutor> getListaDeTutores() {
        return listaDeTutores;
    }
    public void setListaDeTutores(ArrayList<Tutor> listaDeTutores) {
        this.listaDeTutores = listaDeTutores;
    }

    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public ArrayList<Pet> getListaDePets() {
        return listaDePets;
    }
    public void setListaDePet(ArrayList<Pet> listaDePets) {
        this.listaDePets = listaDePets;
    }

    public void adicionarPet(Pet pet){
        this.listaDePets.add(pet);
    }
    public void adicionarTutor(Tutor tutor){
        this.listaDeTutores.add(tutor);
    
    }
    public void removerPet(Pet pet) {
        if (listaDePets != null) {
            listaDePets.remove(pet);
        }
    }

    /* public void imprimirTutores(){
        System.out.println("Lista de tutores cadastrados: ");
        for (Tutor tutor : listaDeTutores){
            System.out.println(tutor.getNome());
        }
    }
    */

    @Override
    public String toString() {
        StringBuilder petString = new StringBuilder();
        for(Pet pet : listaDePets){
            petString.append("Pet: ").append(pet.getNome()).append("\nRaça: ").append(pet.getRaca()).append("\nPeso: ").append(pet.getPeso()).append("\nEspecie: ").append(pet.getEspecie()).append("\n\n");
        }
        return "\nTutor: " + nome + "\n" +
                "CPF: " + cpf + "\n" +
                "\nPets do tutor: \n\n" + petString.toString() + "\n";

    }
}