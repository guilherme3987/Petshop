public class Tosa extends Servico{
    double taxa_tosa;

    public Tosa(String nomeServico, double taxa_tosa) {
        super(nomeServico);
        this.taxa_tosa = taxa_tosa;
        
        //TODO Auto-generated constructor stub
    }

    public double getTaxa_tosa() {
        return taxa_tosa;
    }

    public void setTaxa_tosa(double taxa_tosa) {
        this.taxa_tosa = taxa_tosa;
    }

}