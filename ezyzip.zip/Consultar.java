//Importando bibliotecas
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
public  class Consultar extends JFrame{
  JTextField buscar_cpf = new JTextField(10);
  JButton buscar;
  CadastrarTP cadastrarTP;
  ArrayList<TutorPetInfo> tutorPetLista;
  
  public Consultar(CadastrarTP cadastrarTP) {
     this.cadastrarTP = cadastrarTP;
    this.tutorPetLista = cadastrarTP.getTutorPetLista();
    this.setTitle("Consulta");
    this.setSize(400, 400);
    this.setResizable(false);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    buscar = new JButton("consultar cpf");

    JPanel panel = new JPanel(new GridBagLayout());

    GridBagConstraints gbc = new GridBagConstraints();


    panel.add(new JLabel("CPF do tutor (somente números)"));
    gbc.gridx = 0;
    gbc.gridy = -5;
  
  
    panel.add(buscar_cpf,gbc);

    gbc.gridx = 0;
    gbc.gridy = 7;
    gbc.gridwidth = 2;

    panel.add(buscar,gbc);


    buscar.addActionListener(new ActionListener(){
      @Override
      public void actionPerformed(ActionEvent e) {
        boolean encontrado = false;
        for (TutorPetInfo tutor : tutorPetLista) {
            if (tutor.getCpfTutor().equals(buscar_cpf.getText().trim())) {
                encontrado = true;
                break; 
            }
        }
        if (encontrado) {
            JOptionPane.showMessageDialog(panel, "CPF encontrado");
            for (TutorPetInfo tutor : tutorPetLista) {
              JOptionPane.showMessageDialog(panel, 
              "Nome do Tutor: " + tutor.getNomeTutor()+
              "\nCPF do Tutor: " + tutor.getCpfTutor()+ 
              "\nTelefone do Tutor: " + tutor.getTelefoneTutor());
          }
            
        } else {
            JOptionPane.showMessageDialog(panel, "CPF não encontrado");
        }
      }
    });

    this.add(panel);
    this.setVisible(true);
  }


  
}  
