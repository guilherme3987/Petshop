public class Veterinario {
    
}
