public class Servico{
  private String nomeServico;
  
  public Servico(String nomeServico) {
      this.nomeServico = nomeServico;
  }
  public String getNomeServico() {
    return nomeServico;
  }

 

  //Set
  public void setNomeServico(String nomeServico) {
    this.nomeServico = nomeServico;
  }

}
  
  
      
    
