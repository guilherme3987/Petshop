//Importando bibliotecas
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

//Criando classe
 public class CadastrarTP extends JFrame{
    private JTextField nomeTutor = new JTextField(10);
    private JTextField cpfTutor = new JTextField(10);
    private JTextField telefoneTutor = new JTextField(10);
    private JTextField nomePet = new JTextField(10);
    private JTextField racaPet = new JTextField(10);
    private JTextField especiePet = new JTextField(10);
    private  JTextField pesoPet = new JTextField(10);
    private JButton cadastrar;
    private static ArrayList <TutorPetInfo> tutorPetLista = new ArrayList<TutorPetInfo>();
//Construtor
  public CadastrarTP(){
    this.setTitle("Cadastro tutor/pet");
    this.setSize(400, 400);
    this.setResizable(false);
    //Definindo grid
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    cadastrar = new JButton("Cadastrar");
    JPanel panel = new JPanel(new GridBagLayout());
        
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5);

    // Evento para validar formulário
    cadastrar.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent arg0) {
            if (nomeTutor.getText().trim().isEmpty() || cpfTutor.getText().trim().isEmpty()
                    || telefoneTutor.getText().trim().isEmpty() || nomePet.getText().trim().isEmpty()
                    || racaPet.getText().trim().isEmpty() || especiePet.getText().trim().isEmpty()
                    || pesoPet.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(panel, "Campos vazios");

            } else {
                
                if (cpfTutor.getText().length() != 11 || !cpfTutor.getText().matches("\\d+")) {
                    JOptionPane.showMessageDialog(panel, "CPF inválido");
                    return;
                }
      
                // Validando campos de texto como strings
                if (!nomeTutor.getText().matches("[a-zA-Z\\s]+") || !nomePet.getText().matches("[a-zA-Z\\s]+")
                        || !racaPet.getText().matches("[a-zA-Z\\s]+") || !especiePet.getText().matches("[a-zA-Z\\s]+")) {
                    JOptionPane.showMessageDialog(panel, "Campos de texto devem conter apenas letras e espaços");
                    return;
                }

                if(telefoneTutor.getText().matches("[a-zA-Z\\s]+") || telefoneTutor.getText().length() != 9){
                  JOptionPane.showMessageDialog(panel, "Telefone inválido");
                  return;
                }

                if(pesoPet.getText().matches("[a-zA-Z\\s]+")){
                  JOptionPane.showMessageDialog(panel, "Campo peso deve ser numérico");
                  return;
                }
                if(pesoPet.getText().contains(",")){
                  JOptionPane.showMessageDialog(panel, "Campo peso deve ser com ponto (.)");
                  return;
                }

                JOptionPane.showMessageDialog(panel, "Campos preenchidos");

                TutorPetInfo tutorPetInfo = new TutorPetInfo(nomeTutor.getText(), cpfTutor.getText(),
                        telefoneTutor.getText(), nomePet.getText(), racaPet.getText(), especiePet.getText(),
                        pesoPet.getText());

                tutorPetLista.add(tutorPetInfo);
                
                int resposta = JOptionPane.showConfirmDialog(panel, "Deseja adicionar outro pet?", "Confirmação",
                JOptionPane.YES_NO_OPTION);

                if(resposta == JOptionPane.YES_OPTION){
                  JOptionPane.showMessageDialog(panel, "Preencha os dados do pet");
                  nomePet.setText("");
                  racaPet.setText("");
                  especiePet.setText("");
                  pesoPet.setText("");
                }
                else{
                  JOptionPane.showMessageDialog(panel, "Dados enviados");
                }

            }
        }
    });


    // Nome do Tutor
    gbc.gridx = 0;
    gbc.gridy = 0;
    panel.add(new JLabel("Nome do Tutor:"), gbc);
    gbc.gridx = 1;
    panel.add(nomeTutor, gbc);

    // CPF do Tutor
    gbc.gridx = 0;
    gbc.gridy = 1;
    panel.add(new JLabel("CPF do Tutor:"), gbc);
    gbc.gridx = 1;
    panel.add(cpfTutor, gbc);

    // Telefone do Tutor
    gbc.gridx = 0;
    gbc.gridy = 2;
    panel.add(new JLabel("Telefone do Tutor:"), gbc);
    gbc.gridx = 1;
    panel.add(telefoneTutor, gbc);

    // Nome do Pet
    gbc.gridx = 0;
    gbc.gridy = 3;
    panel.add(new JLabel("Nome do Pet:"), gbc);
    gbc.gridx = 1;
    panel.add(nomePet, gbc);

    // Peso do Pet
    gbc.gridx = 0;
    gbc.gridy = 4;
    panel.add(new JLabel("Peso do Pet:"), gbc);
    gbc.gridx = 1;
    panel.add(pesoPet, gbc);

    // Raça do Pet
    gbc.gridx = 0;
    gbc.gridy = 5;
    panel.add(new JLabel("Raça do Pet:"), gbc);
    gbc.gridx = 1;
    panel.add(racaPet, gbc);

    // Espécie do Pet
    gbc.gridx = 0;
    gbc.gridy = 6;
    panel.add(new JLabel("Espécie do Pet:"), gbc);
    gbc.gridx = 1;
    panel.add(especiePet, gbc);
    
    // Botão de cadastro
    gbc.gridx = 0;
    gbc.gridy = 7;
    gbc.gridwidth = 2;

    
    panel.add(cadastrar, gbc);
    this.add(panel);
    
  }


  
  public JTextField getNomeTutor() {
    return nomeTutor;
  }

  public void setNomeTutor(JTextField nomeTutor) {
    this.nomeTutor = nomeTutor;
  }

  public JTextField getCpfTutor() {
    return cpfTutor;
  }

  public void setCpfTutor(JTextField cpfTutor) {
    this.cpfTutor = cpfTutor;
  }

  public JTextField getTelefoneTutor() {
    return telefoneTutor;
  }

  public void setTelefoneTutor(JTextField telefoneTutor) {
    this.telefoneTutor = telefoneTutor;
  }

  public JTextField getNomePet() {
    return nomePet;
  }

  public void setNomePet(JTextField nomePet) {
    this.nomePet = nomePet;
  }

  public JTextField getRacaPet() {
    return racaPet;
  }

  public void setRacaPet(JTextField racaPet) {
    this.racaPet = racaPet;
  }

  public JTextField getEspeciePet() {
    return especiePet;
  }

  public void setEspeciePet(JTextField especiePet) {
    this.especiePet = especiePet;
  }

  public JTextField getPesoPet() {
    return pesoPet;
  }

  public void setPesoPet(JTextField pesoPet) {
    this.pesoPet = pesoPet;
  }
   public static ArrayList<TutorPetInfo> getTutorPetLista() {
       return tutorPetLista;
   }
}
