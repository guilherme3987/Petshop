public class Banho extends Servico {
    private Funcionario nome;

}
