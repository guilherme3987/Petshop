public class Tosa extends Servico {
    private Funcionario nome;
}
