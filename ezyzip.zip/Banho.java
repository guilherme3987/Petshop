
public class Banho extends Servico{

  double taxa_banho;

  public Banho(String nomeServico,double taxa_banho) {
    super(nomeServico);
    this.taxa_banho = taxa_banho;
    //TODO Auto-generated constructor stub
  }
  public double getTaxa_banho() {
    return taxa_banho;
  }

  public void setTaxa_banho(double taxa_banho) {
    this.taxa_banho = taxa_banho;
  }

}
