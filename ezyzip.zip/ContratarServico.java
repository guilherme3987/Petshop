import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class ContratarServico extends JFrame {
    JTextField cpfTutor = new JTextField(10);
    JButton contratar;
    CadastrarTP cadastrarTP;
    ArrayList<TutorPetInfo> tutorPetLista;

    public ContratarServico(CadastrarTP cadastrarTP) {
        this.cadastrarTP = cadastrarTP;
        this.tutorPetLista = cadastrarTP.getTutorPetLista();

        this.setTitle("Serviço ");
        this.setSize(400, 400);
        this.setResizable(true);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        contratar = new JButton("Serviço");

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        // Adicionando o campo CPF ao painel
        panel.add(new JLabel("CPF do pagante: "));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        panel.add(cpfTutor, gbc);

        JPanel checkboxesPanel = new JPanel(new FlowLayout());
        JCheckBox banhoCheckbox = new JCheckBox("Banho");
        JCheckBox tosaCheckbox = new JCheckBox("Tosa");
        JCheckBox banhoETosaCheckbox = new JCheckBox("Banho e Tosa");

        //Para conseguir que seja escolhido um só 
        ButtonGroup checkBoxGroup = new ButtonGroup();
        checkBoxGroup.add(banhoCheckbox);
        checkBoxGroup.add(tosaCheckbox);
        checkBoxGroup.add(banhoETosaCheckbox);

        checkboxesPanel.add(banhoCheckbox);
        checkboxesPanel.add(tosaCheckbox);
        checkboxesPanel.add(banhoETosaCheckbox);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 4;
        panel.add(checkboxesPanel, gbc);

        contratar.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e) {
              boolean encontrado = false;
      
              for (TutorPetInfo tutor : tutorPetLista) {
                  if (tutor.getCpfTutor().equals(cpfTutor.getText().trim())) {
                      encontrado = true;
                      break;
                  }
              }
      
              if (encontrado) {
                  JTextField nomePetEscolhido = new JTextField(10);
                  JPanel inputPanel = new JPanel();
                  inputPanel.add(new JLabel("Nome do Pet:"));
                  inputPanel.add(nomePetEscolhido);
      
                  double pesoPet = 0.0; // Inicializa a variável de peso
      
                  int result = JOptionPane.showConfirmDialog(null, inputPanel,
                          "Digite o nome do pet", JOptionPane.OK_CANCEL_OPTION);
      
                  if (result == JOptionPane.OK_OPTION) {
                      String nomePetDigitado = nomePetEscolhido.getText().trim();
      
                      for (TutorPetInfo tutor : tutorPetLista) {
                          if (tutor.getCpfTutor().equals(cpfTutor.getText().trim()) &&
                                  tutor.getNomePet().equalsIgnoreCase(nomePetDigitado)) {
                              // Mostra informações sobre o tutor e o pet
                              JOptionPane.showMessageDialog(panel, tutor.getNomeTutor() +
                                      "\n" + tutor.getCpfTutor() + "\n" + tutor.getNomePet());
      
                              
                              pesoPet = Double.parseDouble(tutor.getPesoPet());
                         
      
                              break;
                          }
                      }
      
                      double valorTotal = 0.0;
      
                      if (banhoCheckbox.isSelected()) {
                          Banho banho = new Banho("Banho", 1.50);
                          valorTotal += pesoPet * banho.getTaxa_banho();
                      }
                      if (tosaCheckbox.isSelected()) {
                          Tosa tosa = new Tosa("Tosa", 2.00);
                          valorTotal += pesoPet * tosa.getTaxa_tosa();
                      }
                      if (banhoETosaCheckbox.isSelected()) {
                          Banho_Tosa banho_Tosa = new Banho_Tosa("Banho e Tosa", 2.75);
                          valorTotal += pesoPet * banho_Tosa.getTaxa_banhoEtosa();
                      }
      
                      JOptionPane.showMessageDialog(panel, "Valor total dos serviços: " + valorTotal);
                  }
              } else {
                  JOptionPane.showMessageDialog(panel, "CPF não encontrado");
              }
          }
      });
      

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 4;
        panel.add(contratar, gbc);
        this.add(panel);
        this.setVisible(true);
    }
}
